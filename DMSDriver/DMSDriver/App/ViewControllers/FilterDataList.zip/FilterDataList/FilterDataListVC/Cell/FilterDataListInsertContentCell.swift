//
//  FilterDataListInsertContentCell.swift
//  DMSDriver
//
//  Created by machnguyen_uit on 2/21/19.
//  Copyright © 2019 machnguyen_uit. All rights reserved.
//

import UIKit

class FilterDataListInsertContentCell: UITableViewCell {
    
    @IBOutlet weak var lblTitle:UILabel?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
